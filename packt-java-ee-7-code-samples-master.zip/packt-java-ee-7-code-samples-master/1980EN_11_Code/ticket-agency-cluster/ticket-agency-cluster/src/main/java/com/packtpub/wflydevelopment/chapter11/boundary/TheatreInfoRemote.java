package com.packtpub.wflydevelopment.chapter11.boundary;

public interface TheatreInfoRemote {

    String printSeatList();
}
