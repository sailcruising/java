# Java EE 7 Development with WildFly book code samples
[![Promo code](http://i60.tinypic.com/evcfmu.png)](http://bit.ly/1FHHFA7)

Book is available [here](http://bit.ly/1FHHFA7).
