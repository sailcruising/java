package com.packtpub.wflydevelopment.chapter3.exception;

public class SeatBookedException extends Exception {

    public SeatBookedException(String string) {
        super(string);
    }
}
